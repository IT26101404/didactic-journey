import java.util.Scanner;

public class IT26101404Lab3Q3{
	public static void main(String[] args){
		int amount,remain,count;
		Scanner input = new Scanner(System.in);
		System.out.println("input amount");
		amount = input.nextInt();
		remain=amount;
		count=remain/5000
		remain=remain/5000
		
		System.out.println("5000 note-" + count);
		count=remain/1000
		remain=remain/1000
		
		System.out.println("5000 note-" + count);
		count=remain/5000
		remain=remain/5000
		
		System.out.println("5000 note-" + count);
		count=remain/5000
		remain=remain/5000
		
		System.out.println("5000 note-" + count);
		count=remain/5000
		remain=remain/5000
		
		System.out.println("5000 note-" + count);
		count=remain/5000
		remain=remain/5000
		
		System.out.println("5000 note-" + count);
		count=remain/5000
		remain=remain/5000
		
		System.out.println("5000 note-" + count);
		count=remain/5000
		remain=remain/5000
		
		System.out.println("5000 note-" + count);
	}
}